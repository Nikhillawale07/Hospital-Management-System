class PatientIndividual 
{

}
